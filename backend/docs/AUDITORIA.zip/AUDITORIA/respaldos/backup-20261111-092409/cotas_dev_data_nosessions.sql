--
-- PostgreSQL database dump
--

\restrict cgMn7UytZroyQtkV9XLTPwqQdOACoFLubYLKN0X2Ba6epq0b58OhsHbg2ISDrOw

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
56126375-9316-4efb-b359-053a9b3eafd2	324c803b44dc38f528eca44e4944814177e2000e283e67f91fd09fe8a5895439	2026-10-19 21:09:38.48486+00	20261019160000_init	\N	\N	2026-10-19 21:09:38.310809+00	1
4fb093a8-cccd-471b-8d0e-c090def24cae	738d5739b883addacfd32cd9630360b5bfbaf0dadf3dd6fb16c9494db8e590e4	2026-10-19 22:04:57.242099+00	20261019220000_identity_model	\N	\N	2026-10-19 22:04:56.806917+00	1
ae1cf250-ac02-4eb0-a8f3-21c61e3fcbf6	ccf2d7e0d82d7af992588d963b5951e891ad4f26ba268d0ff87b9a5961e8dc35	2026-10-23 20:19:23.83338+00	20261023180000_local_staff_auth	\N	\N	2026-10-23 20:19:23.800796+00	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.users (id, email, phone, username, password_hash, status, email_verified_at, phone_verified_at, last_login_at, created_at, updated_at, deleted_at, password_changed_at) FROM stdin;
41a503f5-045c-4332-b33a-feca36837364	\N	\N	10200000	\N	ACTIVE	\N	\N	2026-10-23 19:45:23.7+00	2026-10-19 22:06:45.597+00	2026-10-23 19:45:23.765+00	\N	\N
d64ae334-f35b-4ec1-b9ea-6a711e2f253f	\N	\N	operador	$argon2id$v=19$m=19456,p=1,t=2$Oo2xxUHH3FaJWSVdLXHlWQ$sJEW0tx53996TYLm7Ln/2oonhN0GBdhwnyZf1d3AawM	ACTIVE	\N	\N	\N	2026-10-23 20:22:58.973+00	2026-10-23 20:22:58.973+00	\N	2026-10-23 20:22:58.97+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.audit_logs (id, actor_user_id, action, resource_type, resource_id, result, ip_address, correlation_id, metadata, created_at) FROM stdin;
c47f220b-bed9-433b-a705-1052cc64e143	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	0f009450-c3ab-41af-84f5-7682df0b2a42	{"role": "CUSTOMER"}	2026-10-19 22:06:45.677+00
91f3249c-8169-468f-acb7-77ff77d36232	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	781469ae-43c6-4c86-a8ae-52ec58f81b80	{"role": "CUSTOMER"}	2026-10-19 22:08:06.439+00
b179c42b-8601-4cd9-b743-08ec9b7b626d	\N	auth.login	auth	\N	failure	127.0.0.1	2183ae38-2995-49f8-a460-eea076c5d82f	{"reason": "line"}	2026-10-19 22:08:06.631+00
284fe584-ca7f-4a46-bd5e-2545d728b280	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	62d9322e-ff4c-4c8a-9268-646014ce8b64	{"role": "CUSTOMER"}	2026-10-19 22:08:56.107+00
dd3b4544-a78e-4eec-8424-b044b0f71f09	\N	auth.login	auth	\N	failure	127.0.0.1	7701bea6-96cc-4f4c-bd03-7a7c711aa77b	{"reason": "line"}	2026-10-19 22:08:56.371+00
dcc2cac3-6c20-4429-8129-6b0c1541a8ee	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	bd8ff198-92e7-4e2a-8a92-42962a3f0ac3	{"role": "CUSTOMER"}	2026-10-19 22:10:39.919+00
270bc000-64bf-4b46-a9be-4ec8b923fd74	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	41c4c30b-2b66-41e4-bd6c-b5015e214760	{"streamId": "175", "contentType": "live"}	2026-10-19 22:10:52.644+00
06408685-87a3-4d6f-8dba-170f4ed75ea7	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	8ac9ff56-31cf-4a9f-a225-156158bce3b5	{"streamId": "3537", "contentType": "live"}	2026-10-19 22:12:39.162+00
acf4441d-6e26-4a0c-9401-ee887ff1e6d7	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	c30d476a-2d72-4c15-bfd8-fee3a57d118c	{"streamId": "3144", "contentType": "live"}	2026-10-19 22:12:57.005+00
bf4f4432-5dc2-4781-869d-42e25768a03d	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	ffd45e8f-8865-408d-9079-56e41c22a0f1	{"role": "CUSTOMER"}	2026-10-19 22:14:26.176+00
cbf86ff9-4d30-4031-8586-af1ee1becff5	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	bb45c2d6-77f4-4d19-bba7-b53c508669ba	{"streamId": "175", "contentType": "live"}	2026-10-19 22:14:26.492+00
1d9e4cbb-08af-4eb2-877d-f29b92e9f908	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	d19d6989-aeb1-4992-a6d8-f941e7b28ecd	{"role": "CUSTOMER"}	2026-10-19 22:14:39.259+00
91ea69d4-4695-4818-84dc-603b3516c62c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	73f2f4ec-6b16-434f-a6d9-bf626336f63c	{"streamId": "175", "contentType": "live"}	2026-10-19 22:14:39.49+00
bd50d677-cd73-4201-9414-433e2e863ff3	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	43dffdc5-ab40-4265-ab6a-43df8553f92f	{"role": "CUSTOMER"}	2026-10-19 22:15:01.611+00
80c39a7b-2e66-48a1-986e-3f4c8402d366	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	b5d8205e-249b-4206-b322-4fc34829b486	{"streamId": "175", "contentType": "live"}	2026-10-19 22:15:01.886+00
f40de379-dc91-41b2-a39a-afc2eca07552	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	0e55d72c-1387-4808-8634-eac54b45c0ab	{"role": "CUSTOMER"}	2026-10-19 22:16:03.233+00
6244db7d-b855-42f2-b066-3c1aed80270f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	122513ca-ea03-469a-8804-248aae2f06e6	{"streamId": "175", "contentType": "live"}	2026-10-19 22:16:03.453+00
e47aa912-4383-427a-8ace-6560b785268b	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	7f1abed8-e063-4045-b550-5859c70cccb2	{"role": "CUSTOMER"}	2026-10-19 22:17:12.794+00
dd6f5357-1210-4365-91fe-b3eeb761167f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	22972dc9-59b9-4da6-bf21-e5f661ea1f93	{"streamId": "175", "contentType": "live"}	2026-10-19 22:17:13.009+00
72335188-30e1-4855-b3e3-81a7076a44c3	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	8b1ab6a9-89c7-4328-a2ba-82b53f85244a	{"role": "CUSTOMER"}	2026-10-19 22:17:56.802+00
ebf279e2-2fca-4a0a-93b6-c248495b2894	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	14ddf8f8-96b3-4145-bc1e-2cc470840c0d	{"streamId": "175", "contentType": "live"}	2026-10-19 22:17:57.021+00
40677256-8572-4dd0-bc8c-97cbd16a27c7	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	7954461a-6c4f-48eb-9937-6e176ae6ffc6	{"role": "CUSTOMER"}	2026-10-19 22:18:22.945+00
50ccdfa1-ca6e-4d84-a62c-dfc8ec2b7213	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	6babea8f-8a17-4468-88dc-f7d23c90c0b5	{"streamId": "175", "contentType": "live"}	2026-10-19 22:18:23.157+00
e413fc37-63d3-489f-a15f-2e2b4f007510	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	c4e4cefc-e47e-4bcc-96ff-6a79a8abe1a6	{"role": "CUSTOMER"}	2026-10-19 22:18:36.938+00
3bb545d7-f711-43fa-861c-40944c66de58	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	69c574a5-630a-4b67-8441-c12ee7259f02	{"streamId": "175", "contentType": "live"}	2026-10-19 22:18:37.165+00
9fe676ba-cc9b-4e7a-bcba-71f17051ad9c	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	d27787d8-1b00-441a-8451-f95975acdde3	{"role": "CUSTOMER"}	2026-10-19 22:19:27.952+00
845e768a-9955-4765-9dc3-a137b839cbe2	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	e3f21bf5-181a-4ecd-8de8-24a798374f83	{"streamId": "175", "contentType": "live"}	2026-10-19 22:19:28.224+00
da392a13-6ea7-443d-b5d0-ae7a61e6217a	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	1cc0a015-641f-4a78-bffd-a2cb864a8e0e	{"role": "CUSTOMER"}	2026-10-19 22:20:53.39+00
da1e5d8b-ee37-4da1-8335-bd413560a9aa	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	5dabeb62-cd04-4162-9f8e-bebdc52d574d	{"streamId": "175", "contentType": "live"}	2026-10-19 22:20:53.604+00
c00f99bb-235e-40dd-adec-66046a1d5093	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	3f9dd189-96b8-4667-9f13-7f1283548151	{"role": "CUSTOMER"}	2026-10-19 22:22:15.679+00
f8ec1834-be8d-47be-9e29-d6c0286f05d9	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	ea6e7940-0bba-496d-b7c9-9ed4edcaf5a4	{"streamId": "175", "contentType": "live"}	2026-10-19 22:22:15.898+00
b111eb86-bc4e-437e-b539-d8b7673599a6	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	9abcbea6-bcda-4220-8374-7c4866ce6e0f	{"role": "CUSTOMER"}	2026-10-19 22:23:14.393+00
5ddae0ce-9fbc-4126-98a7-eb969f5f12e5	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	59a33532-313c-4d82-9947-ed1f5536aa99	{"streamId": "175", "contentType": "live"}	2026-10-19 22:23:15.32+00
b5d6a06f-4d96-4dbb-b177-a413f780251f	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	8d72d8e7-25de-46aa-a426-d9c5c83dcfe4	{"role": "CUSTOMER"}	2026-10-19 22:23:55.726+00
b9ab0aa4-225d-40a2-a2a2-b21121c13cbc	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	8bea4c5c-89a8-4912-8fa4-655a213714b3	{"streamId": "175", "contentType": "live"}	2026-10-19 22:23:55.939+00
5e734dea-f7fb-4df8-8df6-18d6450d27fc	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	a961612f-c73b-4939-a6e8-50a94335eec5	{"role": "CUSTOMER"}	2026-10-19 22:24:28.795+00
6c8f7037-4a71-4f38-9d09-c196bcfb78ba	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	10b7ab44-e01c-4ffc-a7e5-23a5907a6d3f	{"streamId": "175", "contentType": "live"}	2026-10-19 22:24:28.979+00
c327ed46-5b15-4516-90a2-218da4ab2393	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	1f9239f2-8352-462e-92fb-1bde07776d5f	{"role": "CUSTOMER"}	2026-10-19 22:25:12.858+00
164ca909-3c90-46a3-92c7-7e09096d98fd	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f1df07f0-84f7-428f-b9c3-b75032453d36	{"streamId": "175", "contentType": "live"}	2026-10-19 22:25:13.059+00
7fd12dc6-bded-4a6f-8332-ed6f61685461	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	24ebbe17-b2f7-41ab-80b9-9d4166714852	{"role": "CUSTOMER"}	2026-10-19 22:25:44.758+00
ec71a0b1-e2fb-4ad9-a196-5c50c2a8bd80	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	199145e2-b4d7-4227-819b-4f85c139c1c0	{"streamId": "175", "contentType": "live"}	2026-10-19 22:25:44.953+00
105bd4a2-7f81-41dc-b66a-d388530dad96	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	fb829f70-8d6a-4de1-b30b-e33797163720	{"role": "CUSTOMER"}	2026-10-19 22:26:18.978+00
868c22ad-dab7-4fc3-ac85-3258d3476c72	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	a8b6f5bd-1965-44ae-81c0-40fb92b2150a	{"streamId": "175", "contentType": "live"}	2026-10-19 22:26:19.183+00
e4015445-67b3-485e-b52e-89fa96fefc67	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	2b98697f-c030-42d5-8c46-d66823957527	{"role": "CUSTOMER"}	2026-10-19 22:26:36.674+00
ada753a9-97dc-45ff-ba22-8dcf3dde50be	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	9e69ff37-19ac-4875-b7fc-0f0ff3a61dc1	{"streamId": "3537", "contentType": "live"}	2026-10-19 22:26:41.114+00
5af7558a-33b6-44c7-a630-8616cb6ff0ab	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	4adc8f05-3e82-4c2a-9b46-7b22b43daf16	{"role": "CUSTOMER"}	2026-10-19 22:26:53.712+00
b5891ac7-bf17-41d4-867f-821db529eb59	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	51059d66-2939-4a20-9368-c0fa9f84f355	{"streamId": "175", "contentType": "live"}	2026-10-19 22:26:53.925+00
7ba70a2e-0237-4bca-83fa-34a2f9da5e20	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e55dd7a6-88a1-4f6e-a3bb-637b3d03e465	{"role": "CUSTOMER"}	2026-10-19 22:27:08.841+00
6b65c9b8-6312-451b-b78d-2e885e99fd2d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1d1983a2-a6bd-4370-881d-dfc5dc68f8c5	{"streamId": "175", "contentType": "live"}	2026-10-19 22:27:09.039+00
42620070-63ff-49f1-86bf-10d3a6fde95b	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	7ae17387-1d2f-4ef4-9afa-3a2ad73f3545	{"role": "CUSTOMER"}	2026-10-19 22:27:37.09+00
7d726e23-ac90-4d50-a49f-5c198ada36b8	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	bd529f0f-356f-4efd-a35e-6902fa937a4f	{"streamId": "175", "contentType": "live"}	2026-10-19 22:27:37.368+00
9e3ef3c0-9acd-4a58-85f2-4671dd42ba3b	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	b9190fd3-a8dd-4d66-9848-8ff5ce9eb2ee	{"role": "CUSTOMER"}	2026-10-19 22:28:06.451+00
51395d93-398e-4ff3-9e9d-2d2008e206d2	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	5e9f02a5-2ec7-43b8-ac1b-82fbdd6d4ea6	{"streamId": "175", "contentType": "live"}	2026-10-19 22:28:06.653+00
7f519465-c5c3-4d8f-aa07-d0320326c534	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	4d3d9c49-3935-4d5e-89d4-8a3969f7f338	{"role": "CUSTOMER"}	2026-10-19 22:29:07.248+00
22ec0474-1303-407c-9355-f36318498b97	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	905682d8-6d57-4a4b-8f7d-514795d5e9e0	{"streamId": "175", "contentType": "live"}	2026-10-19 22:29:07.437+00
230ebe59-3914-486b-8c85-6e80aa620697	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e524cb4b-5c33-434c-bef3-a5179b4cb01e	{"role": "CUSTOMER"}	2026-10-19 22:29:46.07+00
121be417-682a-4e97-bc59-01e75193584f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1e3392e9-ac9c-42f5-82a4-0179f238b803	{"streamId": "175", "contentType": "live"}	2026-10-19 22:29:46.283+00
ec460f5a-257b-4bbb-b9a4-abf051b46228	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	8d79111c-0060-4922-a731-cbd17e53e9cf	{"role": "CUSTOMER"}	2026-10-19 22:30:06.739+00
d99d7069-f3b6-4269-ad32-7ba0f28e6f1e	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	9882ea2c-8ab7-47b0-9467-942c29738f3b	{"streamId": "175", "contentType": "live"}	2026-10-19 22:30:06.938+00
d3daa2cc-e77c-4c25-9723-d2c34eb5fecf	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	815f3312-ceb6-4233-a24b-d16e1ab8719d	{"role": "CUSTOMER"}	2026-10-19 22:31:03.058+00
a44083fd-85bf-4a36-af8d-af0d1a1e9e32	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	03f3fa69-e8de-4b6c-b99d-4b14ad8f2559	{"streamId": "175", "contentType": "live"}	2026-10-19 22:31:03.259+00
c181b6c9-6ea1-49c7-bcfc-4db035578408	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	5a48c0b6-24b4-49cf-bba0-64ee53fb3fe8	{"role": "CUSTOMER"}	2026-10-19 22:32:26.841+00
06973872-1532-4170-93a4-1c725dc5c940	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	2cafcc20-e840-410e-ab83-dfc61e171c12	{"streamId": "175", "contentType": "live"}	2026-10-19 22:32:27.021+00
00fba576-4f06-4622-b734-e3676aa0e203	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	c7ec0506-36d2-49e7-af8a-f3d488dcf0a0	{"role": "CUSTOMER"}	2026-10-19 22:35:50.669+00
5f568f3a-b88d-4fc1-9093-3b19b2520a9d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	40f6a72d-0bd4-45f7-b8cb-de58a9befa2c	{"streamId": "175", "contentType": "live"}	2026-10-19 22:35:51.014+00
5c322ff2-51eb-4668-861d-76f571a12f54	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	82de831d-3e04-4907-99bc-3fadbab7d5ae	{"role": "CUSTOMER"}	2026-10-19 22:36:16.418+00
9dc30150-e79c-4874-84a8-68e85c728c2d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1d523572-ea67-477a-8dc6-98f9c59ca9de	{"streamId": "175", "contentType": "live"}	2026-10-19 22:36:16.601+00
5c7a8c9b-167f-478b-812e-9a536ce1d4e9	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	bc829984-ae33-49bc-86bc-8834f3fcc631	{"role": "CUSTOMER"}	2026-10-19 22:37:01.071+00
1254caf9-79ae-45a8-9573-2b63b3ace7df	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	09c11e9a-8290-4fa6-b50f-ad1405e17388	{"streamId": "175", "contentType": "live"}	2026-10-19 22:37:01.293+00
17aa8a2e-cad6-4ff8-9673-6436fd4a3d80	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	a62840ed-a415-44ac-b363-7e466fd0dd52	{"role": "CUSTOMER"}	2026-10-19 22:38:05.57+00
b551dbc7-32fd-4e51-9d29-a8b1f0381104	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	4be4dba9-1df6-4d4e-866b-e35d58181478	{"streamId": "175", "contentType": "live"}	2026-10-19 22:38:05.772+00
4c149f0a-4efa-4097-a04b-c7762f965135	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	f31b9c70-c175-4a22-885c-5394bed4d56c	{"role": "CUSTOMER"}	2026-10-19 22:39:36.011+00
3e5ded94-d55f-4ada-bfe1-ec63b3af739b	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	6fe45e8d-9118-4c3c-ac16-335e030aafb1	{"streamId": "175", "contentType": "live"}	2026-10-19 22:39:36.238+00
ad1262e6-8ee0-47ad-baef-88de8881f129	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	b17b4e36-1d34-41fc-aab6-854f14889769	{"role": "CUSTOMER"}	2026-10-19 22:40:31.901+00
98a0bf2d-32f7-4e72-81da-960a05a121b7	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	af51070d-e9a1-4f42-994a-9d67c78fe23d	{"streamId": "175", "contentType": "live"}	2026-10-19 22:40:32.338+00
35bcc13e-1b88-467e-8025-3a1b86f5b34a	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	88a41545-35ea-4dec-87c1-f2044acfd769	{"role": "CUSTOMER"}	2026-10-19 22:41:07.694+00
65c4ef6b-8ef5-422c-8c1c-69c6efca4af9	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	e9df0a86-fe9e-456e-9b40-3c8644334243	{"streamId": "175", "contentType": "live"}	2026-10-19 22:41:07.946+00
b6dbcdff-5767-4ea4-8770-607fa9f3e1fa	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	a5d04319-445a-40ed-9523-a58411020109	{"role": "CUSTOMER"}	2026-10-19 22:41:30.94+00
0adff47f-23d5-4bd6-9099-6365422913ac	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	34d48b02-3d04-4f81-a08d-478011f6d3c7	{"streamId": "175", "contentType": "live"}	2026-10-19 22:41:31.154+00
d8ac8bd3-5d2f-4e99-a714-0ba3ee236c6b	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	0a00610e-81df-479d-8ff2-e6efbbbddd6a	{"role": "CUSTOMER"}	2026-10-19 22:43:33.993+00
80618110-6569-4b0f-b5eb-211b8ab32d5c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1c5d71b2-2ffe-47bb-8f8a-230bb4cac225	{"streamId": "175", "contentType": "live"}	2026-10-19 22:43:34.19+00
5acc8493-68b4-4125-a284-bce6214716f9	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	00f3356f-0754-414d-abcb-7c01fd721932	{"role": "CUSTOMER"}	2026-10-19 22:44:07.958+00
2a0d28f1-143e-4ea2-b769-8453f85ca995	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	01e4ecd8-b455-489e-a217-c286bfff0e51	{"streamId": "175", "contentType": "live"}	2026-10-19 22:44:08.142+00
015b79be-c821-43c8-bbb5-3831faeb4b2d	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e949a79e-e23c-4c88-bfff-e97bc426f9c5	{"role": "CUSTOMER"}	2026-10-19 22:45:21.45+00
54404ec6-51a2-43ea-abc8-53a751d4ee81	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	538623a9-fabe-4a0d-a05a-a36e8c4054ca	{"streamId": "175", "contentType": "live"}	2026-10-19 22:45:21.979+00
e49134a6-e85d-445c-b432-e3b7000e9863	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e58cd1d0-abd2-4b95-bbf3-ee9b2024bde1	{"role": "CUSTOMER"}	2026-10-19 22:46:50.719+00
72469973-dbb1-47be-a2c2-38b85eb4a580	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	5187091a-4841-4605-a9fd-747f36d27e71	{"streamId": "175", "contentType": "live"}	2026-10-19 22:46:51.044+00
ceaa6f5e-1a45-4f47-9ba4-038b38377938	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	9d8137a8-07c7-43a1-b689-5b92188a2dc7	{"role": "CUSTOMER"}	2026-10-19 22:47:41.817+00
7facb15f-7568-4093-93ad-e7bf9b928b1f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	8c94a1a6-50d1-474b-aea9-aa06d0d02070	{"streamId": "175", "contentType": "live"}	2026-10-19 22:47:42.014+00
168561b0-cbfe-4da7-b1aa-086cf943bd18	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	d19d5a0a-d6b2-411f-af43-5bb74a0999f4	{"role": "CUSTOMER"}	2026-10-19 22:47:42.307+00
04c466eb-ed9b-493c-a3cb-c423295fc960	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1b4c5ead-2e96-4914-be42-a77848d90274	{"streamId": "175", "contentType": "live"}	2026-10-19 22:47:42.493+00
7feccded-95a9-4025-8582-e322aca3aefe	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e9bead85-9452-493a-a21f-d3f04a14b63b	{"role": "CUSTOMER"}	2026-10-19 22:50:15.604+00
8e7e43d2-61c3-4d29-bd90-b7cf66f46222	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	86eea98e-2d9e-4308-8059-c1a8be08e6e4	{"streamId": "175", "contentType": "live"}	2026-10-19 22:50:15.841+00
efc0ca35-eed5-439f-b946-467cc0747a79	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	dcaac7c2-2ded-4cc3-95b1-1d95103beb2a	{"role": "CUSTOMER"}	2026-10-19 22:50:53.067+00
d338b45f-d8cf-49fe-921a-b6b5032c15b0	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	20142951-22df-40fc-906f-7c771c49d5eb	{"streamId": "175", "contentType": "live"}	2026-10-19 22:50:53.262+00
b0e035b2-37fd-4570-b63e-34a73b8d9d7d	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	d9c3fcca-b101-42cf-93d9-207f061e10c4	{"role": "CUSTOMER"}	2026-10-19 22:51:46.912+00
508fed6b-8caf-4b17-a0a4-b092d2b65992	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	640d762e-b268-4e60-8988-9533cffcbcfe	{"streamId": "175", "contentType": "live"}	2026-10-19 22:51:47.104+00
6e10591f-4cd4-4f9d-b987-26f4479ba727	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	54c46aa6-a3f6-4c9f-8908-b423c4f5f489	{"role": "CUSTOMER"}	2026-10-19 22:52:18.137+00
7c3bd305-4b74-4e40-8f84-5063ccc16cfb	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	d5433ec7-6112-489d-a5ee-446438a36d02	{"streamId": "175", "contentType": "live"}	2026-10-19 22:52:18.358+00
02d4d0cf-e1ea-4d81-ad13-f8d04013d30d	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	b8d3bc5a-9341-4cbc-b685-50658320ac4d	{"role": "CUSTOMER"}	2026-10-19 22:52:53.385+00
567df185-ef7f-421e-8edb-49f6a70217ff	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	28976c44-fa93-4b48-ad6f-9f551a348865	{"streamId": "175", "contentType": "live"}	2026-10-19 22:52:53.591+00
8dbece7d-58c9-4974-aa15-55ad6b6cd37b	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	fcace6d1-5e64-4aa4-84d0-17c7bbbab97e	{"role": "CUSTOMER"}	2026-10-19 22:55:43.373+00
109cb296-0aa1-4f8f-89b1-8e324c604e52	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	e8a3489a-c9f2-49c5-ab17-3ecd5806d204	{"streamId": "175", "contentType": "live"}	2026-10-19 22:55:43.57+00
f1fde3fd-3caf-4481-887e-62629fb088de	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	d68c0e53-71f2-4dd5-91cc-1fb8613925cb	{"role": "CUSTOMER"}	2026-10-19 22:56:21.957+00
e0407579-88c8-453d-b666-8c3a70326c21	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	a2295242-17a5-4565-9814-df37add4382e	{"streamId": "175", "contentType": "live"}	2026-10-19 22:56:22.144+00
02d2c8ed-a38b-4ac5-86ef-20742bc6fd5e	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	2e8b794a-7188-41fa-899b-05aa7c42a5cf	{"role": "CUSTOMER"}	2026-10-19 22:57:18.566+00
fd5d83fc-848e-4f30-9310-5a78f557d80b	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	309a1d64-2743-4917-b01d-358b5835865f	{"streamId": "175", "contentType": "live"}	2026-10-19 22:57:18.812+00
5f279e52-c62c-431e-9785-ba7754e452d3	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	59d42518-0b91-43a9-b43c-666e094eb872	{"role": "CUSTOMER"}	2026-10-19 22:57:24.273+00
06dde4d7-0dab-44ee-8055-5edaf0d61766	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	554a5fc5-adcb-4bd1-8d51-61a852a84d61	{"streamId": "175", "contentType": "live"}	2026-10-19 22:57:28.188+00
111bbddf-b3e0-4074-8e35-151d516cee03	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	71af94a5-958f-45c2-9d0f-03a6526beddd	{"streamId": "175", "contentType": "live"}	2026-10-19 22:57:28.237+00
62ab0712-05b2-46b0-9fc8-265d821b1ba8	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	6f0d914a-5bef-45c7-8cd9-6b51d898404b	{"streamId": "175", "contentType": "live"}	2026-10-19 22:57:51.768+00
6f876160-151c-4c22-93aa-76176cb074eb	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	b2d8aec9-a346-46a4-95eb-6f3a488ed6ca	{"role": "CUSTOMER"}	2026-10-19 22:58:06.104+00
29d89198-9718-4ab8-9762-b976d745f13d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	d3220f6a-f72c-41a0-8324-6be82959fb8b	{"streamId": "175", "contentType": "live"}	2026-10-19 22:58:06.366+00
a02f16dd-3946-413c-9c5b-7a943dcef2bb	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	03dd2e11-46c1-4928-a287-75c541f39174	{"streamId": "3665", "contentType": "live"}	2026-10-19 22:58:08.192+00
6d8fba77-2ef7-42dd-9f72-4afe9f5aa964	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	dd2639ed-8958-46cd-9dd3-f43a90ec54fd	{"role": "CUSTOMER"}	2026-10-19 22:58:42.245+00
81ce4bc0-5852-4346-9155-a29acff3daae	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f08d067e-d922-4c6f-825f-2ce09e1c8d10	{"streamId": "175", "contentType": "live"}	2026-10-19 22:58:42.422+00
b8fb68f9-340f-4a42-ad9a-7278d3d391e7	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	fd86fa32-0db4-4891-8af6-f11a68a95e66	{"role": "CUSTOMER"}	2026-10-19 22:59:06.144+00
0c8bbb7f-826c-41d1-8198-aa88771da45b	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	392f1242-f556-4227-957f-2ecae3841275	{"streamId": "175", "contentType": "live"}	2026-10-19 22:59:06.329+00
c5717e00-8d4e-4560-953b-0dd380270ade	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	7ec19c93-a6bd-4db3-8395-cc3c75c59c01	{"streamId": "3665", "contentType": "live"}	2026-10-19 23:00:05.596+00
df7b2779-a3a0-4973-a688-eee3f68172a0	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	d2b70fa7-cc8a-4550-8af7-9f447e5777b2	{"role": "CUSTOMER"}	2026-10-19 23:00:19.784+00
b84c2820-4ed0-4e83-84c5-71e0deb86ef3	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	64029b22-33fa-4ff6-be15-2102e5291cf2	{"streamId": "175", "contentType": "live"}	2026-10-19 23:00:20.007+00
6ecc58c5-5af0-48be-bfff-ae04dfe09506	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	4f79936d-a786-4d9d-9441-9cc96b5fa740	{"role": "CUSTOMER"}	2026-10-19 23:00:34.905+00
12984ed5-78d1-4164-87af-58fe7928e36d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	a9e34ed7-d626-4477-b25d-5eede05335ee	{"streamId": "175", "contentType": "live"}	2026-10-19 23:00:35.099+00
40da4670-f5f3-49a9-9fd6-0a3d0b8e2c8e	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	324aa701-663d-4cb1-8d56-0640a646f687	{"role": "CUSTOMER"}	2026-10-19 23:00:48.665+00
7e60b1b5-b961-4ff6-a508-8eac50b9e8d8	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	d3d7a1e2-e1a1-4a7b-8fc3-e35c265d8114	{"streamId": "175", "contentType": "live"}	2026-10-19 23:00:48.871+00
ff41d909-3b63-43a5-b0dd-35e792cc079b	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	87ba5a10-4daf-4abe-8232-0cc6829c0b14	{"role": "CUSTOMER"}	2026-10-19 23:01:48.014+00
2565a213-be5b-4592-8a83-1e9e5526dd37	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	0e46a27c-0c3e-4b58-8b76-518dc8b035ec	{"streamId": "175", "contentType": "live"}	2026-10-19 23:01:48.238+00
71ad338b-6d1c-4975-aeae-4af008548413	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	19193537-0fed-4056-bec2-58c941385130	{"streamId": "3144", "contentType": "live"}	2026-10-19 23:05:11.225+00
c66ac65a-6a9e-49d2-ae22-d6253df2ff77	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	619ac6f5-57b2-4741-bdfb-f92bc778bb4e	{"streamId": "3144", "contentType": "live"}	2026-10-19 23:05:11.268+00
ea1c1242-1cb7-44ca-a8ac-b0619abc9696	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	baf56372-a777-4c63-89be-494cb94660cc	{"streamId": "3145", "contentType": "live"}	2026-10-19 23:05:27.095+00
e1f884e8-eb17-418a-a24d-777e9af55f7a	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	74db93d0-4cd1-4928-8b6b-a963b6250cb1	{"role": "CUSTOMER"}	2026-10-19 23:05:31.102+00
ce206037-6aa2-4c0e-bd23-f1c3d5dc1ced	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f4e67037-b2ee-41a5-aa3f-950811407abc	{"streamId": "175", "contentType": "live"}	2026-10-19 23:05:32.267+00
80045a79-93ae-4dd2-8261-11725e8d5f7f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	9a5d4ca9-bfb4-4184-929d-9d12df8420cd	{"streamId": "3540", "contentType": "live"}	2026-10-19 23:05:44.478+00
c56737f7-aa7d-446f-a4d8-abada98ea654	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1f447c29-f5ea-4b0d-b82f-960bbe59414c	{"streamId": "175", "contentType": "live"}	2026-10-19 23:06:14.717+00
115546c1-68e7-4542-a8c4-cbd41f2876de	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	6e34f8fb-9acc-4632-a993-67ea40b68cd1	{"role": "CUSTOMER"}	2026-10-19 23:07:09.035+00
d2805899-c6b9-4839-b027-8e2a307f3321	41a503f5-045c-4332-b33a-feca36837364	auth.logout	auth	\N	success	127.0.0.1	81c068ed-c363-4613-837f-9b1a2d5299c9	\N	2026-10-19 23:08:48.999+00
bae8516e-6c01-4e54-8d6a-b9b76d56b063	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	2b302171-6b76-4af2-82e2-edc364ebe3f4	{"role": "CUSTOMER"}	2026-10-19 23:08:58.57+00
e58c2c24-b3de-4503-9f55-0cefc03efef2	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	0d9e175e-d8f1-4e27-9c47-93603003874c	{"streamId": "3144", "contentType": "live"}	2026-10-19 23:09:07.532+00
c3a96d5a-1942-4793-9e5b-994b69bb39f2	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	14d5062c-6597-4391-9c77-919ca5ada9b0	{"streamId": "3144", "contentType": "live"}	2026-10-19 23:09:10.207+00
4709bfef-fa56-48ce-b703-d831e864912d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	404ba610-1328-4330-a51c-fa31d88a590d	{"streamId": "3540", "contentType": "live"}	2026-10-19 23:09:17.674+00
6bc30ddc-24e3-4987-b3b7-2f300ba40f3e	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	43135fc8-78a9-4720-b566-9acb1b85f23a	{"streamId": "3659", "contentType": "live"}	2026-10-19 23:09:20.144+00
7af3a30a-4a72-40f4-8e59-e417eb0071c8	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	c85d3c2f-be10-4ceb-8b81-5138ef3b1014	{"streamId": "3147", "contentType": "live"}	2026-10-19 23:09:24.635+00
4a2d645b-35be-48ed-a66c-a1567c24bcdc	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	785450e6-2d25-46bc-b2b4-ed1cf75e2235	{"streamId": "3537", "contentType": "live"}	2026-10-19 23:06:04.121+00
1d498277-536e-481f-a699-d9a81652484a	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	5a747cad-bed9-4fc8-9fc7-e912cffd5daf	{"role": "CUSTOMER"}	2026-10-19 23:06:12.683+00
89552be9-8a90-49db-97b4-d6ac5046ea46	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	3aa60ab1-26b6-4832-8186-d11df1d57175	{"streamId": "175", "contentType": "live"}	2026-10-19 23:07:10.036+00
4423b034-1f91-4aff-9dec-13cfcccc4043	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	2204e7c1-dee7-4576-8c87-bef07e5adfe4	{"streamId": "3537", "contentType": "live"}	2026-10-19 23:09:00.939+00
090fb41e-4b40-4172-88ca-b2a1f2d4c431	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	d91b7025-3134-4957-ba88-4534c315d694	{"streamId": "3537", "contentType": "live"}	2026-10-19 23:09:09.562+00
56af0b0b-b5ec-40a7-b679-ccd294458b6c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	56723650-2f06-4f78-a824-9d411705663b	{"streamId": "3145", "contentType": "live"}	2026-10-19 23:09:10.652+00
bd6a94a8-18bd-43ac-9011-302d7cbd380c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	41a10da6-ea1f-4ef2-a1b5-5c15f8907cd3	{"streamId": "3146", "contentType": "live"}	2026-10-19 23:09:22.519+00
12eca40e-a952-4a7e-b140-21d6902f704e	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	75824d6a-221a-4557-bcdf-58d6e249b626	{"streamId": "3152", "contentType": "live"}	2026-10-19 23:10:37.841+00
0acffcb3-30b3-42ab-a8bf-f39bf17cd72f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	c57dcf35-7c94-4b4f-bd56-07900afec562	{"streamId": "3662", "contentType": "live"}	2026-10-19 23:10:38.241+00
b32c957b-3028-4037-b321-9fe1ca955096	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	c65a16e5-9294-4fe0-b3b8-71564c9e501e	{"streamId": "175", "contentType": "live"}	2026-10-19 23:11:00.276+00
a697159d-f279-4b5b-a9a3-7aa5cce82af6	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	7f1e6a04-6a96-4bde-921a-a8edf2d8af60	{"streamId": "3537", "contentType": "live"}	2026-10-19 23:11:10.47+00
440f37df-009c-42f4-b716-b7218f5dd681	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	31fb9bc5-7248-4d28-b227-295ca2b93313	{"role": "CUSTOMER"}	2026-10-20 19:32:14.959+00
5b9f7348-ca06-4a72-8024-d8e58e5c5274	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	81a62b53-f111-4598-818e-d3504480ce3e	{"streamId": "3537", "contentType": "live"}	2026-10-20 19:32:22.244+00
fbd69bbc-1f0f-425c-a4b4-a1bc02f786b9	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f403d34f-e2b5-44cb-8adf-2004c7e22421	{"streamId": "3144", "contentType": "live"}	2026-10-20 19:32:34.47+00
08af0abb-95d1-4920-9ee4-0f88e106146f	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	f94ced2d-ae80-4bc0-8afb-4171fd01af99	{"role": "CUSTOMER"}	2026-10-20 19:34:28.635+00
ae484457-3291-4cd4-a931-9d51e93319f1	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	593781f6-729b-4a89-be5b-33d3a31e19e3	{"streamId": "3144", "contentType": "live"}	2026-10-20 19:34:35.135+00
4c8ffe58-2a37-4639-b6e1-a0436cb44ef6	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	269816d5-ab16-4bef-b604-0fc30cb48521	{"role": "CUSTOMER"}	2026-10-20 19:42:44.481+00
7eeb03b5-210e-4e9c-9c01-cd8b2d514357	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e97f2e20-7b05-432c-ae67-d36bbcd210b3	{"role": "CUSTOMER"}	2026-10-20 19:44:13.288+00
de1033b3-31f0-4e6a-95e6-046a03989c75	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	936aacaf-b860-4ab4-89d8-6b80caa1284b	{"streamId": "3144", "contentType": "live"}	2026-10-20 19:44:19.893+00
1af26565-3bba-438e-8fea-266eab39fe9c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f6cbfdfe-d31e-4434-b697-9648483358f5	{"streamId": "3537", "contentType": "live"}	2026-10-20 19:46:05.212+00
f37e8815-2bdf-4f05-bdce-7209e2e9061e	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f8a5cc36-39dc-40d1-962a-2cb8b38aa849	{"streamId": "3157", "contentType": "live"}	2026-10-20 19:46:19.366+00
416b2cfc-542a-45a5-b3cc-2d958fae4e20	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	393edfba-84e8-4d59-be8f-c0427982bd97	{"role": "CUSTOMER"}	2026-10-20 19:56:19.048+00
09e8e662-4095-4d04-9ed1-df81c0f58a5c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	e01e40f9-18be-4a79-b0e1-bd6fa798062d	{"streamId": "3144", "contentType": "live"}	2026-10-20 19:56:21.376+00
765db74d-edc3-479c-ba9e-e31775b49464	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	e55a64b3-1ed2-44b9-9e22-6d1aaf9be09a	{"streamId": "3145", "contentType": "live"}	2026-10-20 19:56:26.096+00
80715702-96f7-46be-a9e0-48ad8a9978bd	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	a5345e26-4d1a-4b02-b987-b30b94952623	{"role": "CUSTOMER"}	2026-10-20 19:56:55.829+00
5b604d46-a6cd-4293-ba0c-aec4e9803129	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	fd3eadce-5eb9-47e7-b210-ec29b836d0f6	{"streamId": "3144", "contentType": "live"}	2026-10-20 19:56:58.14+00
9bc69e0f-85e8-460b-a933-3de9dddc753a	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	b888b267-e9ef-44ea-a301-342faab68f73	{"streamId": "3145", "contentType": "live"}	2026-10-20 19:57:02.472+00
10624388-7594-4f67-984a-204ffde2b445	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	2aa0078f-e8c1-4e44-b18c-a92a0a160717	{"role": "CUSTOMER"}	2026-10-20 19:57:28.996+00
4795a8d6-409c-4f33-bb4a-4283be947421	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	69e32c0d-be55-45f4-a2f2-aad8a0baf3c7	{"streamId": "3145", "contentType": "live"}	2026-10-20 19:57:34.586+00
601d221e-e19a-4217-a32e-a4e0c2bf2cdd	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	e838ba58-226d-48ad-935c-6b86d7861d3b	{"role": "CUSTOMER"}	2026-10-20 19:58:48.358+00
d9a01cc1-cbcc-4b8f-95d6-f746826ff101	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	1e7450c7-7964-4361-93d4-9db6781ef024	{"streamId": "3537", "contentType": "live"}	2026-10-20 19:58:56.209+00
8a84c242-3a4f-4a8b-8829-5475a1a40fb7	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	9dc3e558-9413-4fcb-9795-37d3ac5caf1c	{"streamId": "3169", "contentType": "live"}	2026-10-20 19:59:08.01+00
49dd708d-aa73-4db5-90ca-ee460d6e0214	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	47e01c66-fc82-46f9-818e-fbb5601127c0	{"streamId": "3555", "contentType": "live"}	2026-10-20 19:59:17.831+00
5da2179a-d5e1-411c-b2bc-50d4088ec14e	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	0a76d74e-6cd9-41b3-a9da-59a08b2bb57e	{"role": "CUSTOMER"}	2026-10-20 20:19:59.783+00
92156417-3085-4645-bded-1e766919abaf	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	5383ae84-426c-4adf-bacc-948030dd78ca	{"role": "CUSTOMER"}	2026-10-20 20:20:03.725+00
a23b216e-acfd-4d5e-a783-30530c62bbc7	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	2bec48db-2dd6-4946-9895-804247ff6650	{"streamId": "359", "contentType": "vod"}	2026-10-20 20:20:10.482+00
2ed6b4ba-a685-4f47-b47e-5e0cfb2d5e6d	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f51fc023-9cc6-488e-896b-bfe103d39b6f	{"streamId": "699", "contentType": "series"}	2026-10-20 20:20:19.207+00
6dbb49ad-ed02-436c-adcb-d8b3993c125a	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	6c4a94e9-8f1d-410e-a577-2c2dfde03e23	{"role": "CUSTOMER"}	2026-10-20 20:23:55.764+00
5336d7f8-869f-4789-a5c6-657cf1ebb2e2	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	d04f02b8-498a-43d0-a796-5ee2ca2694b0	{"streamId": "3537", "contentType": "live"}	2026-10-20 20:24:02.627+00
866876a4-6b73-4e92-b3c4-7e4b293778bf	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	a1181234-7426-4ac4-bbd7-3f8777eccbf3	{"role": "CUSTOMER"}	2026-10-20 20:28:55.007+00
b1fbe363-b1d7-47f7-855e-594cc9a30ed0	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f3884536-2b81-4be8-abf5-bf7a337152cb	{"streamId": "2247", "contentType": "vod"}	2026-10-20 20:28:58.237+00
50e12c43-fa41-4d39-98be-53334499f471	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	d7b578b4-b591-4f6c-9424-5592b776b5db	{"streamId": "456", "contentType": "vod"}	2026-10-20 20:30:43.978+00
d7556631-2acc-45a1-a463-a3dc3dcd0e35	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	7039b083-57e8-40cf-8127-8019df0defd3	{"streamId": "456", "contentType": "vod"}	2026-10-20 20:30:44.079+00
2f3c0080-9f00-4f0d-aebd-dea62680f340	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	f081640e-68cc-4c0b-8876-229d36795ccb	{"streamId": "456", "contentType": "vod"}	2026-10-20 20:30:46.208+00
070b7fd2-7e92-4ad4-b2c2-15e14aa29d75	\N	auth.login	auth	\N	failure	172.27.0.1	13089e96-aff2-47b3-ac1b-d44c0a394d3e	{"reason": "line"}	2026-10-20 21:23:10.487+00
c21bf23e-4f5a-4c91-959d-cdbdba51bde6	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	172.27.0.1	d5cc086e-c280-45c9-bd4b-d84db082a7e3	{"role": "CUSTOMER"}	2026-10-20 21:23:10.679+00
d3aa1ce9-394d-4562-b463-3899653dc936	\N	auth.login	auth	\N	failure	172.27.0.1	6e331283-3979-4f14-882d-5108891edd2c	{"reason": "line"}	2026-10-20 21:25:17.302+00
7248abd1-df2d-4719-a15b-04e69afc2104	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	172.27.0.1	3379641b-2da2-498a-9241-85c0bc730b56	{"role": "CUSTOMER"}	2026-10-20 21:25:17.385+00
d2e621af-bea6-42fc-8753-426bd7e5e7cd	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	failure	172.27.0.1	c95c325e-af22-41c2-a343-e83438d1a350	{"reason": "not_found", "streamId": "999999999999", "contentType": "live"}	2026-10-20 21:25:18.568+00
5e323c7a-5dc9-4d6c-b7c4-98175250a9a7	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	failure	172.27.0.1	934aefe4-f347-48c1-9ab6-840601ce9557	{"reason": "not_found", "streamId": "3360", "contentType": "series"}	2026-10-20 21:25:18.636+00
8f699b58-77b3-4822-a5d8-0a3d342dacaf	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	172.27.0.1	c33fb549-b9e3-4f2e-8e3e-f990924672b6	{"streamId": "3537", "contentType": "live"}	2026-10-20 21:25:18.744+00
ee7f71c0-3d4f-4897-95b2-a656206c74f2	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	172.27.0.1	074a3716-985d-4c70-a6c6-2b16a8d28756	{"streamId": "456", "contentType": "vod"}	2026-10-20 21:25:19.873+00
99c83523-40c1-4d6d-a06f-ebbc45a6a95b	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	172.27.0.1	64950bff-12c0-4cbd-856d-7407b643f698	{"streamId": "3360", "contentType": "series"}	2026-10-20 21:25:20.721+00
0496e1b9-0064-4ed3-a0fb-7448b0de72b7	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	172.27.0.1	26fd0ce2-9712-444e-b35b-65082dc971bc	{"role": "CUSTOMER"}	2026-10-20 21:26:03.707+00
4101c038-817e-4d4b-b5cf-52630ad45455	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	172.27.0.1	4f50c23b-6717-4883-918d-46362d364c8c	{"streamId": "3537", "contentType": "live"}	2026-10-20 21:26:03.833+00
5483a912-c8ad-4505-8565-367be032f84d	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	172.27.0.1	22ef004a-450e-4d82-9a4e-a86a9801ae15	{"role": "CUSTOMER"}	2026-10-20 21:26:14.545+00
66183034-7df4-4cb7-b0bd-58790663e4c9	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	172.27.0.1	0a06485f-444f-47b4-ad03-dc5f3c65530c	{"streamId": "3537", "contentType": "live"}	2026-10-20 21:26:14.689+00
8415ef6e-4482-4595-9b61-6ff8255dd075	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	2e70b8c2-737e-48e9-8dd4-91b1bd041348	{"role": "CUSTOMER"}	2026-10-21 19:56:01.728+00
bfbf63f5-9b79-43d0-8221-7991953c5291	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	66f635a3-64c4-4f38-bc54-e3c3704cda3b	{"role": "CUSTOMER"}	2026-10-21 19:59:41.758+00
f2fddea3-2728-424e-a200-66ba09f3e17c	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	93bc22bb-a837-4d1f-a69c-c52595458267	{"role": "CUSTOMER"}	2026-10-21 20:01:04.781+00
a14b133c-acd0-40bd-8377-20e0e7561d9e	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	268d1cdb-4477-43fb-878e-c37e8e678f13	{"role": "CUSTOMER"}	2026-10-21 20:01:04.794+00
0a505d48-954e-421e-bb8c-3611953bb251	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	48200c89-294c-4738-b760-43920dece86f	{"streamId": "3537", "contentType": "live"}	2026-10-21 20:01:11.299+00
7ead1742-bed0-4701-a795-26c0684a9407	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	7673e696-5282-477e-ac0f-0302a58b1e4a	{"streamId": "3144", "contentType": "live"}	2026-10-21 20:04:31.702+00
eb35adbf-9be2-4955-aaa0-9c832f7d483c	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	5afa4313-61c1-4f44-a018-b5cd3ea38959	{"streamId": "3144", "contentType": "live"}	2026-10-21 20:04:31.809+00
b674f7da-9f04-4428-925c-a8e4b4d22641	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	acf97fb5-880a-430b-8ae6-7c97a0edd714	{"streamId": "3144", "contentType": "live"}	2026-10-21 20:04:31.841+00
c628cd64-a126-4aec-89d7-f387019b268f	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	77c2b66c-05f6-4d16-9582-edef6bcbbfa0	{"streamId": "3537", "contentType": "live"}	2026-10-21 20:05:13.42+00
aaac7633-ef90-446a-b771-c4b462fce506	41a503f5-045c-4332-b33a-feca36837364	playback.authorize	playback	\N	success	127.0.0.1	c5c557e6-d3bd-4e8a-a285-dce0d3fc1733	{"streamId": "3144", "contentType": "live"}	2026-10-21 20:05:15.579+00
caa1d861-a2ca-401e-b5b7-7283c800a859	\N	auth.login	auth	\N	failure	127.0.0.1	aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee	{"reason": "line"}	2026-10-23 19:34:50.625+00
70b2e404-efd8-4155-9d92-a01f25512bc2	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	1b6adfc2-bb5b-4195-ad3f-2b07fba15274	{"role": "CUSTOMER"}	2026-10-23 19:35:12.667+00
de4fe7b0-09f0-49b0-aee8-f776ac936ce1	41a503f5-045c-4332-b33a-feca36837364	auth.refresh	auth	\N	success	127.0.0.1	4e89bdc0-5207-443f-8393-904826b9fad9	\N	2026-10-23 19:35:12.798+00
bb50c7a8-3c9b-4e6c-a1a9-3495c656bf4d	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee	{"role": "CUSTOMER"}	2026-10-23 19:45:10.827+00
2f1d608e-927b-48b0-b3ba-4a19422eef3e	41a503f5-045c-4332-b33a-feca36837364	auth.login	auth	\N	success	127.0.0.1	040826c2-dd20-42f9-8468-c274628249f6	{"role": "CUSTOMER"}	2026-10-23 19:45:23.911+00
6c2165a8-13d1-4f4e-b3c9-a2143433a432	41a503f5-045c-4332-b33a-feca36837364	auth.logout	auth	\N	success	127.0.0.1	cccccccc-bbbb-4ccc-8ddd-eeeeeeeeeeee	\N	2026-10-23 19:45:23.98+00
757e60fd-503d-45e5-aed1-79367dc7880b	\N	auth.login	auth	\N	failure	127.0.0.1	af481502-5e1f-4708-b7d4-1361b58c7f92	{"reason": "line"}	2026-10-23 20:22:52.488+00
e621b227-3c46-45b3-ab1f-5a006d2f086d	d64ae334-f35b-4ec1-b9ea-6a711e2f253f	auth.mfa_enrollment_challenge	auth	\N	pending	127.0.0.1	60ac7c4f-940c-461f-8736-c21b3ade07e5	\N	2026-10-23 20:23:10.482+00
\.


--
-- Data for Name: auth_challenges; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.auth_challenges (id, user_id, purpose, token_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.devices (id, user_id, platform, device_name, device_identifier_hash, status, last_seen_at, created_at, revoked_at) FROM stdin;
e1f42abc-0fb0-4de7-ba8b-9ab858c12806	41a503f5-045c-4332-b33a-feca36837364	WEB	Navegador	7cfacab971aee673680ee4c4ab4930ac81098bf63d8563e70753a8a0398bd916	ACTIVE	2026-10-21 20:01:04.779+00	2026-10-19 22:10:39.91+00	\N
c10f400c-1ca3-42da-834d-29df50cf3a02	41a503f5-045c-4332-b33a-feca36837364	WEB	Navegador	790d07412441be02567b6156235ed000214282a002128f6b51812b1356892181	ACTIVE	2026-10-23 19:35:12.602+00	2026-10-19 22:06:45.662+00	\N
464db501-dcce-41e7-a429-6e02a30ad7df	41a503f5-045c-4332-b33a-feca36837364	WEB	Navegador	a4170d77851263d4c65c4e657c05655ca4c54396bb26c5563dc4e7f33d33422a	ACTIVE	2026-10-23 19:45:23.865+00	2026-10-23 19:45:10.805+00	\N
774a1e9d-568a-452f-b644-cf1a7e6daeaf	41a503f5-045c-4332-b33a-feca36837364	WEB	Navegador	42eced814c50d3c46865a6cecf0ed79ad06436fb0a916960c5dc04cc92afd119	ACTIVE	2026-10-20 20:28:54.972+00	2026-10-19 23:05:31.084+00	\N
\.


--
-- Data for Name: iptv_accounts; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.iptv_accounts (id, user_id, provider, external_account_ref, username, password_encrypted, status, expires_at, last_verified_at, created_at, updated_at) FROM stdin;
e2b20bc2-f2f2-4177-a3cf-b16418405f62	41a503f5-045c-4332-b33a-feca36837364	XUI	10200000	10200000	cGbqBiOwn9t4uZbVnk0L4rBDD060mzikI9NOgyARcNv0TqvA	ACTIVE	\N	2026-10-23 19:45:23.7+00	2026-10-19 22:06:45.619+00	2026-10-23 19:45:23.806+00
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.permissions (id, code, description, created_at, updated_at) FROM stdin;
aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1	catalog.read	Leer categorías y canales.	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2	playback.authorize	Autorizar una referencia de reproducción.	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3	audit.read	Consultar auditoría.	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa4	users.read	Consultar usuarios de la aplicación.	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa5	devices.manage	Revocar dispositivos y sus sesiones.	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa6	users.manage	Administrar cuentas de la aplicación.	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.roles (id, code, name, description, is_system, created_at, updated_at) FROM stdin;
11111111-1111-4111-8111-111111111111	CUSTOMER	Cliente	Consulta el catálogo y autoriza reproducción de su línea.	t	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
22222222-2222-4222-8222-222222222222	OPERATOR	Operador	Opera auditoría, usuarios y dispositivos. Requiere MFA.	t	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	ADMIN	Administrador	Incluye los permisos de operador y la gestión de usuarios.	t	2026-10-19 22:04:56.329+00	2026-10-19 22:04:56.329+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.role_permissions (role_id, permission_id, created_at) FROM stdin;
11111111-1111-4111-8111-111111111111	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1	2026-10-19 22:04:56.329+00
11111111-1111-4111-8111-111111111111	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2	2026-10-19 22:04:56.329+00
22222222-2222-4222-8222-222222222222	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1	2026-10-19 22:04:56.329+00
22222222-2222-4222-8222-222222222222	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2	2026-10-19 22:04:56.329+00
22222222-2222-4222-8222-222222222222	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3	2026-10-19 22:04:56.329+00
22222222-2222-4222-8222-222222222222	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa4	2026-10-19 22:04:56.329+00
22222222-2222-4222-8222-222222222222	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa5	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa4	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa5	2026-10-19 22:04:56.329+00
33333333-3333-4333-8333-333333333333	aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa6	2026-10-19 22:04:56.329+00
\.


--
-- Data for Name: user_mfa_methods; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.user_mfa_methods (id, user_id, method, secret_encrypted, status, created_at, confirmed_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: cotas
--

COPY public.user_roles (user_id, role_id, assigned_at) FROM stdin;
41a503f5-045c-4332-b33a-feca36837364	11111111-1111-4111-8111-111111111111	2026-10-19 22:06:45.597+00
d64ae334-f35b-4ec1-b9ea-6a711e2f253f	22222222-2222-4222-8222-222222222222	2026-10-23 20:22:58.99+00
\.


--
-- PostgreSQL database dump complete
--

\unrestrict cgMn7UytZroyQtkV9XLTPwqQdOACoFLubYLKN0X2Ba6epq0b58OhsHbg2ISDrOw

