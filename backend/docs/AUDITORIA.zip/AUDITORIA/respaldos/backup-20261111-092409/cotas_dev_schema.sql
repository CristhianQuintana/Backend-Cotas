--
-- PostgreSQL database dump
--

\restrict EbpnwXPpj83HLanzzBqDby2UbBr4YHMCh3VljlKNGifGQLt3hgK3WT1cUyNZEvt

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AuditResult; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."AuditResult" AS ENUM (
    'success',
    'failure',
    'pending'
);


ALTER TYPE public."AuditResult" OWNER TO cotas;

--
-- Name: AuthChallengePurpose; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."AuthChallengePurpose" AS ENUM (
    'MFA_RECOVERY'
);


ALTER TYPE public."AuthChallengePurpose" OWNER TO cotas;

--
-- Name: DevicePlatform; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."DevicePlatform" AS ENUM (
    'WEB',
    'ANDROID',
    'IOS',
    'TV',
    'OTHER'
);


ALTER TYPE public."DevicePlatform" OWNER TO cotas;

--
-- Name: DeviceStatus; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."DeviceStatus" AS ENUM (
    'ACTIVE',
    'REVOKED'
);


ALTER TYPE public."DeviceStatus" OWNER TO cotas;

--
-- Name: IptvAccountStatus; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."IptvAccountStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'EXPIRED',
    'ERROR'
);


ALTER TYPE public."IptvAccountStatus" OWNER TO cotas;

--
-- Name: MfaMethodStatus; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."MfaMethodStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'REVOKED'
);


ALTER TYPE public."MfaMethodStatus" OWNER TO cotas;

--
-- Name: MfaMethodType; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."MfaMethodType" AS ENUM (
    'TOTP'
);


ALTER TYPE public."MfaMethodType" OWNER TO cotas;

--
-- Name: SessionRevocationReason; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."SessionRevocationReason" AS ENUM (
    'LOGOUT',
    'ROTATED',
    'REUSE',
    'ADMIN',
    'SECURITY'
);


ALTER TYPE public."SessionRevocationReason" OWNER TO cotas;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: cotas
--

CREATE TYPE public."UserStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'SUSPENDED',
    'DISABLED'
);


ALTER TYPE public."UserStatus" OWNER TO cotas;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO cotas;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    actor_user_id uuid,
    action character varying(64) NOT NULL,
    resource_type character varying(64) NOT NULL,
    resource_id character varying(64),
    result public."AuditResult" NOT NULL,
    ip_address character varying(64),
    correlation_id character varying(64),
    metadata jsonb,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO cotas;

--
-- Name: auth_challenges; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.auth_challenges (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    purpose public."AuthChallengePurpose" NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp(3) with time zone NOT NULL,
    consumed_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.auth_challenges OWNER TO cotas;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.devices (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    platform public."DevicePlatform" NOT NULL,
    device_name character varying(80),
    device_identifier_hash character varying(64) NOT NULL,
    status public."DeviceStatus" DEFAULT 'ACTIVE'::public."DeviceStatus" NOT NULL,
    last_seen_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    revoked_at timestamp(3) with time zone
);


ALTER TABLE public.devices OWNER TO cotas;

--
-- Name: iptv_accounts; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.iptv_accounts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(32) DEFAULT 'XUI'::character varying NOT NULL,
    external_account_ref character varying(128),
    username character varying(64),
    password_encrypted text,
    status public."IptvAccountStatus" DEFAULT 'ACTIVE'::public."IptvAccountStatus" NOT NULL,
    expires_at timestamp(3) with time zone,
    last_verified_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iptv_accounts OWNER TO cotas;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.permissions (
    id uuid NOT NULL,
    code character varying(64) NOT NULL,
    description character varying(240),
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.permissions OWNER TO cotas;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO cotas;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(80) NOT NULL,
    description character varying(240),
    is_system boolean DEFAULT true NOT NULL,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.roles OWNER TO cotas;

--
-- Name: user_mfa_methods; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.user_mfa_methods (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    method public."MfaMethodType" NOT NULL,
    secret_encrypted text,
    status public."MfaMethodStatus" DEFAULT 'PENDING'::public."MfaMethodStatus" NOT NULL,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    confirmed_at timestamp(3) with time zone,
    revoked_at timestamp(3) with time zone
);


ALTER TABLE public.user_mfa_methods OWNER TO cotas;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_roles OWNER TO cotas;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    device_id uuid,
    family_id uuid NOT NULL,
    refresh_token_hash character varying(64) NOT NULL,
    ip_address character varying(64),
    user_agent character varying(256),
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) with time zone,
    expires_at timestamp(3) with time zone NOT NULL,
    revoked_at timestamp(3) with time zone,
    revoke_reason public."SessionRevocationReason",
    replaced_by_id uuid
);


ALTER TABLE public.user_sessions OWNER TO cotas;

--
-- Name: users; Type: TABLE; Schema: public; Owner: cotas
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(254),
    phone character varying(32),
    username character varying(64),
    password_hash text,
    status public."UserStatus" DEFAULT 'PENDING'::public."UserStatus" NOT NULL,
    email_verified_at timestamp(3) with time zone,
    phone_verified_at timestamp(3) with time zone,
    last_login_at timestamp(3) with time zone,
    created_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(3) with time zone,
    password_changed_at timestamp(3) with time zone
);


ALTER TABLE public.users OWNER TO cotas;

--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: iptv_accounts iptv_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.iptv_accounts
    ADD CONSTRAINT iptv_accounts_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_mfa_methods user_mfa_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_mfa_methods
    ADD CONSTRAINT user_mfa_methods_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_action_created_at_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX audit_logs_action_created_at_idx ON public.audit_logs USING btree (action, created_at);


--
-- Name: audit_logs_actor_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX audit_logs_actor_user_id_created_at_idx ON public.audit_logs USING btree (actor_user_id, created_at);


--
-- Name: auth_challenges_token_hash_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX auth_challenges_token_hash_key ON public.auth_challenges USING btree (token_hash);


--
-- Name: auth_challenges_user_id_purpose_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX auth_challenges_user_id_purpose_idx ON public.auth_challenges USING btree (user_id, purpose);


--
-- Name: devices_user_hash_active_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX devices_user_hash_active_key ON public.devices USING btree (user_id, device_identifier_hash) WHERE (status = 'ACTIVE'::public."DeviceStatus");


--
-- Name: devices_user_id_status_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX devices_user_id_status_idx ON public.devices USING btree (user_id, status);


--
-- Name: iptv_accounts_one_active_per_user_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX iptv_accounts_one_active_per_user_key ON public.iptv_accounts USING btree (user_id) WHERE (status = 'ACTIVE'::public."IptvAccountStatus");


--
-- Name: iptv_accounts_provider_ref_active_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX iptv_accounts_provider_ref_active_key ON public.iptv_accounts USING btree (provider, external_account_ref) WHERE ((status = 'ACTIVE'::public."IptvAccountStatus") AND (external_account_ref IS NOT NULL));


--
-- Name: iptv_accounts_user_id_status_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX iptv_accounts_user_id_status_idx ON public.iptv_accounts USING btree (user_id, status);


--
-- Name: permissions_code_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX permissions_code_key ON public.permissions USING btree (code);


--
-- Name: role_permissions_permission_id_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX role_permissions_permission_id_idx ON public.role_permissions USING btree (permission_id);


--
-- Name: roles_code_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX roles_code_key ON public.roles USING btree (code);


--
-- Name: user_mfa_methods_one_active_totp_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX user_mfa_methods_one_active_totp_key ON public.user_mfa_methods USING btree (user_id, method) WHERE (status = 'ACTIVE'::public."MfaMethodStatus");


--
-- Name: user_mfa_methods_user_id_status_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX user_mfa_methods_user_id_status_idx ON public.user_mfa_methods USING btree (user_id, status);


--
-- Name: user_roles_role_id_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX user_roles_role_id_idx ON public.user_roles USING btree (role_id);


--
-- Name: user_sessions_family_id_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX user_sessions_family_id_idx ON public.user_sessions USING btree (family_id);


--
-- Name: user_sessions_refresh_token_hash_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX user_sessions_refresh_token_hash_key ON public.user_sessions USING btree (refresh_token_hash);


--
-- Name: user_sessions_user_id_revoked_at_expires_at_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX user_sessions_user_id_revoked_at_expires_at_idx ON public.user_sessions USING btree (user_id, revoked_at, expires_at);


--
-- Name: users_deleted_at_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX users_deleted_at_idx ON public.users USING btree (deleted_at);


--
-- Name: users_email_active_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX users_email_active_key ON public.users USING btree (email) WHERE ((deleted_at IS NULL) AND (email IS NOT NULL));


--
-- Name: users_phone_active_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX users_phone_active_key ON public.users USING btree (phone) WHERE ((deleted_at IS NULL) AND (phone IS NOT NULL));


--
-- Name: users_status_idx; Type: INDEX; Schema: public; Owner: cotas
--

CREATE INDEX users_status_idx ON public.users USING btree (status);


--
-- Name: users_username_active_key; Type: INDEX; Schema: public; Owner: cotas
--

CREATE UNIQUE INDEX users_username_active_key ON public.users USING btree (username) WHERE ((deleted_at IS NULL) AND (username IS NOT NULL));


--
-- Name: audit_logs audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: auth_challenges auth_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devices devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iptv_accounts iptv_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.iptv_accounts
    ADD CONSTRAINT iptv_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_mfa_methods user_mfa_methods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_mfa_methods
    ADD CONSTRAINT user_mfa_methods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cotas
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict EbpnwXPpj83HLanzzBqDby2UbBr4YHMCh3VljlKNGifGQLt3hgK3WT1cUyNZEvt

